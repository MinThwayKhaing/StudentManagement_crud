
package com.sms.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sms.helper.UserHelper;
import com.sms.model.UserBean;
import com.sms.persistant.dao.UserDAO;
import com.sms.persistant.dto.UserRequestDTO;
import com.sms.persistant.dto.UserResponseDTO;

@Controller
public class UserController {

	@Autowired
	private UserDAO dao;

	@RequestMapping(value = "/displayUserRegister", method = RequestMethod.GET)
	public ModelAndView displayUserRegister(ModelMap map) {
		UserBean userBean = new UserBean();
		return new ModelAndView("USR001", "userBean", userBean);
	}

	@PostMapping("/userRegister")
	public String userRegister(@ModelAttribute("userBean") @Validated UserBean userBean, BindingResult br,
			ModelMap model) {
		if (br.hasErrors()) {
			return "USR001";
		} else if (!userBean.getPassword().equals(userBean.getConfirmPassword())) {
			model.addAttribute("passwordError", "Password doesn't match!");
			return "USR001";
		} else if (UserHelper.isEmailExist(userBean.getEmail())) {
			model.addAttribute("error", "Email already exists.");
			return "USR001";
		} else {
			userBean.setId(UserHelper.idGenerator());
			UserRequestDTO dto = new UserRequestDTO();
			dto.setId(userBean.getId());
			dto.setName(userBean.getName());
			dto.setEmail(userBean.getEmail());
			dto.setPassword(userBean.getPassword());
			dto.setRole(userBean.getRole());
			dao.insertUser(dto);
			model.addAttribute("success", "Successfully registered.");
			return "redirect:/showUser";
		}

	}

	@GetMapping("/showUser")
	public String showUser(ModelMap model, HttpSession session) {
		if (session.getAttribute("user") == null) {
			return "redirect:/";
		} else {
			ArrayList<UserResponseDTO> list = dao.selectUserAll();
			model.addAttribute("userList", list);
			return "USR003";
		}

	}


	@GetMapping("/userSearch")
	public String userSearch(ModelMap model, @RequestParam("id") String id, @RequestParam("name") String name) {
		if (name.isBlank() && id.isBlank()) {
			return "redirect:/showUser";
		} else {
			UserRequestDTO dto = new UserRequestDTO();
			dto.setId(id);
			UserResponseDTO searchById = dao.selectUserById(dto);
			ArrayList<UserResponseDTO> list = dao.selectUsersByName(name);
			list.add(searchById);
			model.addAttribute("userList", list);
			return "USR003";

		}
	}

	@GetMapping("/showUserUpdate/{id}")
	public String showUserUpdate(ModelMap model, @PathVariable("id") String id) {
		UserRequestDTO dto = new UserRequestDTO();
		dto.setId(id);
		UserResponseDTO userRes = new UserDAO().selectUserById(dto);
		model.addAttribute("user", userRes);
		return "USR002";
	}

	@PostMapping("/userUpdate")
	public String userUpdate(@RequestParam("name") String name, @RequestParam("email") String email,
			@RequestParam("password") String password, @RequestParam("cfpassword") String cf_password,
			@RequestParam("role") String role, @RequestParam("id") String id, HttpSession session, ModelMap model) {

		UserBean userBean = new UserBean();
		userBean.setId(id);
		userBean.setEmail(email);
		userBean.setName(name);
		userBean.setPassword(password);
		userBean.setRole(role);
		if (name.isBlank() || email.isBlank() || password.isBlank()) {
			session.setAttribute("user", userBean);
			model.addAttribute("error", "Field cannot be blank! ");
			return "USR002";
		} else if (!password.equals(cf_password)) {
			session.setAttribute("user", userBean);
			model.addAttribute("error", "Password doesn't match.");
			return "USR002";
		} else {
			UserRequestDTO dto = new UserRequestDTO();
			dto.setId(userBean.getId());
			dto.setName(userBean.getName());
			dto.setEmail(userBean.getEmail());
			dto.setPassword(userBean.getPassword());
			dto.setRole(userBean.getRole());

			dao.updateUser(dto);
			return "redirect:/showUser";
		}
	}

	@RequestMapping("/userDelete/{id}")
	public String userDelete(@PathVariable("id") String id) {
		UserRequestDTO dto = new UserRequestDTO();
		dto.setId(id);
		dao.deleteUser(dto);
		return "redirect:/showUser";
	}

}
