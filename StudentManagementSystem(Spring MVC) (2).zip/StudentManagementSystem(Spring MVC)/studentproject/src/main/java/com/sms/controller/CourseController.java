package com.sms.controller;




import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sms.helper.CourseHelper;
import com.sms.model.CourseBean;
import com.sms.persistant.dao.CourseDAO;
import com.sms.persistant.dto.CourseRequestDTO;


@Controller
public class CourseController {
	@Autowired
	private CourseDAO courseDAO;	
	
	@GetMapping("/showCourseRegister")
	public ModelAndView showCourseRegister(HttpSession session) {
		if(session.getAttribute("user") == null) {
			return new ModelAndView("redirect:/");			
		}else {
			CourseBean bean = new CourseBean();
			String courseId = CourseHelper.idGenerator();
			session.setAttribute("courseID", courseId);
			return new ModelAndView("BUD003","courseBean",bean);
			
		}
		
	}
	
	@PostMapping("/courseRegister")
	public String courseRegister(@ModelAttribute("courseBean") @Validated CourseBean courseBean, BindingResult br, ModelMap model) {
		if(br.hasErrors()) {
			return "BUD003";
		}else if(CourseHelper.isCourseExist(courseBean.getName())) {
			model.addAttribute("error",courseBean.getName()+" already exists! ");
			return "BUD003";
		}
		else {	
			String courseId = courseBean.getId();
			String courseName = courseBean.getName();
			CourseRequestDTO dto = new CourseRequestDTO();
			dto.setId(courseId);
			dto.setName(courseName);
			courseDAO.insertCourse(dto);
			model.addAttribute("success",courseName+" is successfully added!");
			return "BUD003";
		}
		
	}
	
}
