package com.sms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sms.helper.StudentHelper;
import com.sms.model.StudentBean;
import com.sms.persistant.dao.CourseDAO;
import com.sms.persistant.dao.StudentCourseDAO;
import com.sms.persistant.dao.StudentDAO;
import com.sms.persistant.dto.CourseResponseDTO;
import com.sms.persistant.dto.StudentRequestDTO;
import com.sms.persistant.dto.StudentResponseDTO;



@Controller
public class StudentController {
	@Autowired
	private StudentCourseDAO studentCourseDAO;

	@GetMapping("/showStudentRegister")
	public ModelAndView showStudentRegister(HttpSession session) {
		if (session.getAttribute("user") == null) {
			return new ModelAndView("redirect:/");
		} else {

			StudentBean studentBean = new StudentBean();
			String id = StudentHelper.idGenerator();
			session.setAttribute("stuID", id);
			return new ModelAndView("STU001", "studentBean", studentBean);
		}
	}

	@ModelAttribute(value = "courseList")
	public List<String> courseList() {
		ArrayList<String> list = new ArrayList<>();
		ArrayList<CourseResponseDTO> courseLists = new CourseDAO().selectCourseAll();
		for (CourseResponseDTO course : courseLists) {
			list.add(course.getName());
		}
		return list;

	}

	@PostMapping("/studentRegister")
	public String studentRegister(@ModelAttribute("studentBean") @Validated StudentBean studentBean, BindingResult br,
			ModelMap map) {
		if (br.hasErrors()) {
			return "STU001";
		}
		StudentRequestDTO dto = new StudentRequestDTO();
		dto.setId(studentBean.getId());
		dto.setName(studentBean.getName());
		dto.setDob(studentBean.getDob());
		dto.setPhone(studentBean.getPhone());
		dto.setGender(studentBean.getGender());
		dto.setEducation(studentBean.getEducation());
		new StudentDAO().insertStudent(dto);
		ArrayList<String> courses = studentBean.getCourse();
		for (String course : courses) {
			String courseId = new CourseDAO().selectCourseIdByCourseName(course);
			studentCourseDAO.insertStudentCourse(dto.getId(), courseId);
		}
		return "redirect:/showStudentAll";
	}

	@GetMapping("/showStudentAll")
	public String showStudentAll(ModelMap model, HttpSession session) {
		if (session.getAttribute("user") == null) {
			return "redirect:/";
		} else {

			ArrayList<StudentResponseDTO> studentList = new StudentDAO().selectStudentAll();
			Map<String, String> map = new HashMap<>();
			for (StudentResponseDTO student : studentList) {
				String courses = new StudentCourseDAO().selectCoursesByStudentId(student.getId());
				map.put(student.getId(), courses);
			}
			model.addAttribute("map", map);
			model.addAttribute("studentList", studentList);
			return "STU003";
		}
	}

	@GetMapping("/searchStudent")
	public String searchStudent(@RequestParam("id") String id, @RequestParam("name") String name,
			@RequestParam("course") String course, ModelMap model) {
		if (id.isBlank() && name.isBlank() && course.isBlank()) {
			return "redirect:/showStudentAll";
		} else {
			ArrayList<StudentResponseDTO> studentList = new ArrayList<>();	
			studentList = new StudentCourseDAO().searchByIdNameCourse(id, name, course);
			System.out.println(studentList);
			Map<String, String> map = new HashMap<>();
			for (StudentResponseDTO student : studentList) {
				String courses = new StudentCourseDAO().selectCoursesByStudentId(student.getId());
				map.put(student.getId(), courses);
			}

			model.addAttribute("studentList", studentList);
			model.addAttribute("map", map);
			return "STU003";
		}
	}

	@GetMapping("/seeMore/{id}")
	public ModelAndView seeMore(@PathVariable("id") String id) {
		StudentRequestDTO dto = new StudentRequestDTO();
		dto.setId(id);
		StudentResponseDTO studentDTO = new StudentDAO().selectStudent(dto);
		StudentBean student = new StudentBean();
		student.setId(studentDTO.getId());
		student.setName(studentDTO.getName());
		student.setDob(studentDTO.getDob());
		student.setGender(studentDTO.getGender());
		student.setPhone(studentDTO.getPhone());
		student.setEducation(studentDTO.getEducation());

		// Selected course
		ArrayList<String> courseList = studentCourseDAO.selectCourseListByStudentId(student.getId());
		student.setCourse(courseList);
		return new ModelAndView("STU002", "studentBean", student);
	}

	@GetMapping("/deleteStudent/{id}")
	public String deleteStudent(@PathVariable("id") String id) {
		studentCourseDAO.deleteCourseListByStudentId(id);
		StudentRequestDTO dto = new StudentRequestDTO();
		dto.setId(id);
		new StudentDAO().deleteStudent(dto);
		return "redirect:/showStudentAll";
	}

	@GetMapping("/showStudentUpdate/{id}")
	public ModelAndView showStudentUpdate(@PathVariable("id") String id) {
		StudentRequestDTO dto = new StudentRequestDTO();
		dto.setId(id);
		StudentResponseDTO studentDTO = new StudentDAO().selectStudent(dto);
		StudentBean student = new StudentBean();
		student.setId(studentDTO.getId());
		student.setName(studentDTO.getName());
		student.setDob(studentDTO.getDob());
		student.setGender(studentDTO.getGender());
		student.setPhone(studentDTO.getPhone());
		student.setEducation(studentDTO.getEducation());
		ArrayList<String> courseList = studentCourseDAO.selectCourseListByStudentId(student.getId());
		student.setCourse(courseList);
		return new ModelAndView("STU002-01", "studentBean", student);
	}

	@PostMapping("/updateStudent")
	public String updateStudent(@ModelAttribute("studentBean") @Validated StudentBean bean, BindingResult br) {
		if (br.hasErrors()) {
			return "STU002-01";
		}

		StudentRequestDTO dto = new StudentRequestDTO();
		dto.setId(bean.getId());
		dto.setName(bean.getName());
		dto.setDob(bean.getDob());
		dto.setPhone(bean.getPhone());
		dto.setGender(bean.getGender());
		dto.setEducation(bean.getEducation());
		new StudentDAO().updateStudent(dto);

		// Delete existing course related with the student and add again
		new StudentCourseDAO().deleteCourseListByStudentId(bean.getId());

		ArrayList<String> courses = bean.getCourse();
		for (String course : courses) {
			String courseId = new CourseDAO().selectCourseIdByCourseName(course);
			studentCourseDAO.insertStudentCourse(dto.getId(), courseId);
		}

		return "redirect:/showStudentAll";

	}
}
