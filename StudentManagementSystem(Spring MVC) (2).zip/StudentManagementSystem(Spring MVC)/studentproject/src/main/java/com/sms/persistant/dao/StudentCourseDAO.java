package com.sms.persistant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.sms.persistant.dto.StudentResponseDTO;

@Service("StudentCourseDAO")
public class StudentCourseDAO {

	public static Connection con = null;
	static {
		try {
			con = MyConnection.getCon();		
		}catch(Exception e) {
			System.out.println("Connection in Student Dao error.");
		}
	}
	
	public int insertStudentCourse(String studentId, String courseId) {
		int result = 0;
		String sql = "Insert into student_course(student_id, course_id) values(?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, studentId);
			ps.setString(2, courseId);
			result = ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Student course insert fail...");
		}
		
		return result;
	}

	public String selectCoursesByStudentId(String id) {	
		String courses = "";
		String sql = "select course.name from course join student_course on course.id = student_course.course_id where student_course.student_id = ?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,id);
			ResultSet rs =  ps.executeQuery();
			while(rs.next()) {
				if(courses.isBlank()) {
					courses = rs.getString(1);
				}else
					courses = courses+", "+rs.getString(1);
			}			
			
		} catch (SQLException e) {
			System.out.println("Course Selection with student id Fail.");
		}
		return courses;
	}
	
	public String selectCourseIdByStudentId(String id) {	
		String courses = "";
		String sql = "select course.id from course join student_course on course.id = student_course.course_id where student_course.student_id = ?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,id);
			ResultSet rs =  ps.executeQuery();
			while(rs.next()) {
				if(courses.isBlank()) {
					courses = rs.getString(1);
				}else
					courses = courses+", "+rs.getString(1);
			}			
			
		} catch (SQLException e) {
			System.out.println("Course Id Selection with student id Fail.");
		}
		return courses;
	}
	
	public ArrayList<String> selectCourseListByStudentId(String id) {
		ArrayList<String> course= new ArrayList<String>();
		String sql = "select course.name from course join student_course on course.id = student_course.course_id  "
				+ "where student_course.student_id = ? ";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				course.add(rs.getString(1));
			}
		} catch (SQLException e) {
			System.out.println("course list selection error");
		}
		return course;
	}
	
	public int deleteCourseListByStudentId(String id) {
		int result = 0;
		String sql = "delete from student_course where student_id = ?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);			
			result = ps.executeUpdate();
			System.out.println("delete success");
		} catch (SQLException e) {
			System.out.println("Delete student_coures fails.");
		}
		
		return result;
	}
	
	public ArrayList<StudentResponseDTO> searchByIdNameCourse(String id, String name, String course){
		ArrayList<StudentResponseDTO> list = new ArrayList<>();
		String sql = "select distinct student.id, student.name\n"
				+ "from student\n"
				+ "join student_course \n"
				+ "on student.id = student_course.student_id\n"
				+ "join course\n"
				+ "on student_course.course_id = course.id\n"
				+ "where student.id = ? or student.name = ? or course.name = ?; ";		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, name);
			ps.setString(3, course);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				StudentResponseDTO studentRes = new StudentResponseDTO();
				studentRes.setId(rs.getString("id"));
				studentRes.setName(rs.getString("name"));
							
				list.add(studentRes);
			}
		} catch (SQLException e) {
			System.out.println(" search selection error...");
		}
		return list;
	}
	
}
