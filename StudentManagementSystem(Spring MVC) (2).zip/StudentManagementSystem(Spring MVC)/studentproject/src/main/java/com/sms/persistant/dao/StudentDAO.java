package com.sms.persistant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.sms.persistant.dto.StudentRequestDTO;
import com.sms.persistant.dto.StudentResponseDTO;



public class StudentDAO {


	public static Connection con = null;
	static {
		try {
			con = MyConnection.getCon();		
		}catch(Exception e) {
			System.out.println("Connection in Student Dao error.");
		}
	}
	
	
	public int insertStudent(StudentRequestDTO dto) {
		int result = 0;
		String sql = "Insert into student (id, name, dob, gender, phone, education) "
				+ "values(?, ?, ?, ?, ?, ?)";		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getDob());
			ps.setString(4, dto.getGender());
			ps.setString(5, dto.getPhone());
			ps.setString(6, dto.getEducation());
			result = ps.executeUpdate();
			System.out.println("Student insert success.");
			
		} catch (SQLException e) {
			System.out.println("Student Insert Fail.");
		}
		return result;
	}
	public int updateStudent(StudentRequestDTO dto) {
		int result = 0;
		String sql = "update student set name = ?, dob = ?, gender = ?,"
				+ "phone = ?, education = ?, photo = ? where id = ?";		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(7, dto.getId());
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getDob());
			ps.setString(3, dto.getGender());
			ps.setString(4, dto.getPhone());
			ps.setString(5, dto.getEducation());
			result = ps.executeUpdate();
			System.out.println("Student table updated successfully.");
			
		} catch (SQLException e) {
			System.out.println("Student update Fail.");
		}
		return result;
	}
	
	public int deleteStudent(StudentRequestDTO dto) {
		int result = 0;
		String sql = "delete from student where id = ?";		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println("Student delete Fail.");
		}
		return result;
	}
	
	public StudentResponseDTO selectStudent(StudentRequestDTO dto) {	
		StudentResponseDTO studentRes = new StudentResponseDTO();
		String sql = "select * from student where id=?";		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());			
			ResultSet rs =  ps.executeQuery();
			while(rs.next()) {
				studentRes.setId(rs.getString("id"));
				studentRes.setName(rs.getString("name"));
				studentRes.setDob(rs.getString("dob"));
				studentRes.setGender(rs.getString("gender"));
				studentRes.setPhone(rs.getString("phone"));
				studentRes.setEducation(rs.getString("education"));
				
				
			}			
			
		} catch (SQLException e) {
			System.out.println("Student Selection with id Fail.");
		}
		return studentRes;
		
	}
	 

	public ArrayList<StudentResponseDTO> selectStudentAll() {	
		ArrayList<StudentResponseDTO> list = new ArrayList<>();
		String sql = "select * from student ";		
		try {
			PreparedStatement ps = con.prepareStatement(sql);		
			ResultSet rs =  ps.executeQuery();
			while(rs.next()) {
				StudentResponseDTO studentRes = new StudentResponseDTO();
				studentRes.setId(rs.getString("id"));
				studentRes.setName(rs.getString("name"));
				studentRes.setDob(rs.getString("dob"));
				studentRes.setGender(rs.getString("gender"));
				studentRes.setPhone(rs.getString("phone"));
				studentRes.setEducation(rs.getString("education"));
			
				
				list.add(studentRes);
			}			
			
		} catch (SQLException e) {
			System.out.println("Student Selection all Fail.");
		}
		return list;
		
	}



}
