package com.sms.persistant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.sms.persistant.dto.UserRequestDTO;
import com.sms.persistant.dto.UserResponseDTO;



@Service("UserDAO")
public class UserDAO {
	public static Connection con = null;
	static {
		try {
			con = MyConnection.getCon();
		} catch (Exception e) {
			System.out.println("Connection in User DAO error.");
		}
	}

	public int insertUser(UserRequestDTO dto) {
		int result = 0;
		String sql = "Insert into user (id, name, email, password, role) " + "values(?, ?, ?, ?, ?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getEmail());
			ps.setString(4, dto.getPassword());
			ps.setString(5, dto.getRole());
			result = ps.executeUpdate();

		} catch (SQLException e) {
			System.out.println("User Insert Fail.");
		}
		return result;
	}

	public int updateUser(UserRequestDTO dto) {
		int result = 0;
		String sql = "update user set name=? , email = ?, password = ?, role = ?" + "where id = ?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(5, dto.getId());
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getEmail());
			ps.setString(3, dto.getPassword());
			ps.setString(4, dto.getRole());
			result = ps.executeUpdate();
			System.out.println("User table updated successfully.");

		} catch (SQLException e) {
			System.out.println("User update Fail.");
		}
		return result;
	}

	public int deleteUser(UserRequestDTO dto) {
		int result = 0;
		String sql = "delete from user where id = ?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			result = ps.executeUpdate();
			System.out.println("User table deteled successfully.");

		} catch (SQLException e) {
			System.out.println("User delete Fail.");
		}
		return result;
	}

	public UserResponseDTO selectUserById(UserRequestDTO dto) {
		UserResponseDTO userRes = new UserResponseDTO();
		String sql = "select * from user where id=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				userRes.setId(rs.getString("id"));
				userRes.setName(rs.getString("name"));
				userRes.setEmail(rs.getString("email"));
				userRes.setPassword(rs.getString("password"));
				userRes.setRole(rs.getString("role"));
			}

		} catch (SQLException e) {
			System.out.println("Selection with id Fail.");
		}
		return userRes;

	}

	public ArrayList<UserResponseDTO> selectUsersByName(String name) {
		ArrayList<UserResponseDTO> list = new ArrayList<UserResponseDTO>();
		String sql = "select * from user where name=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				UserResponseDTO userRes = new UserResponseDTO();
				userRes.setId(rs.getString("id"));
				userRes.setName(rs.getString("name"));
				userRes.setEmail(rs.getString("email"));
				userRes.setPassword(rs.getString("password"));
				userRes.setRole(rs.getString("role"));
				list.add(userRes);
			}

		} catch (SQLException e) {
			System.out.println("Selection with name Fail.");
		}
		return list;

	}

	public ArrayList<UserResponseDTO> selectUserAll() {
		ArrayList<UserResponseDTO> list = new ArrayList<UserResponseDTO>();
		String sql = "select * from user ";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				UserResponseDTO userRes = new UserResponseDTO();
				userRes.setId(rs.getString("id"));
				userRes.setName(rs.getString("name"));
				userRes.setEmail(rs.getString("email"));
				userRes.setPassword(rs.getString("password"));
				userRes.setRole(rs.getString("role"));
				list.add(userRes);
			}

		} catch (SQLException e) {
			System.out.println("User Selection all Fail.");
		}
		return list;

	}

}
